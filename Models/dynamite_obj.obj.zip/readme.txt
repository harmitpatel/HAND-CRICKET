-- 3dvia.com   --

The zip file dynamite_obj.obj.zip contains the following files :
- readme.txt
- dynamite_obj.obj
- dynamite_obj.mtl
- dtexture.jpg


-- Model information --

Model Name : Dynamite
Author : NA
Publisher : 3DRS

You can view this model here :
http://www.3dvia.com/content/53A9B7495B6D7F51
More models about this author :
http://www.3dvia.com/3DRS


-- Attached license --

A license is attached to the Dynamite model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution-NonCommercial-ShareAlike 2.5
Detailed license : http://creativecommons.org/licenses/by-nc-sa/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
